CREATE PROCEDURE queryPlayerNumberAndChampionSumByTeamId(IN  p_teamId    INT, OUT playerSumForTeam INT(10) UNSIGNED,
                                                         OUT championSum INT(10) UNSIGNED)
  BEGIN
SELECT COUNT(player.playerId) FROM player WHERE player.teamId=p_teamId INTO playerSumForTeam;
SELECT SUM(player.championNumber) FROM player WHERE player.teamId=p_teamId INTO championSum;
END;
