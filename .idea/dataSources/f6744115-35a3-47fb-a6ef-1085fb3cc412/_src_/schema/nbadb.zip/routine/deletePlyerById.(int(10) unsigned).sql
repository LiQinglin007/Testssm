CREATE PROCEDURE deletePlyerById(IN id INT(10) UNSIGNED)
  BEGIN
DELETE FROM player where player.playerId=id;
END;
