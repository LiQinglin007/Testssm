CREATE FUNCTION addPlayer(playerName VARCHAR(20), playerPosition VARCHAR(20), playerNumber INT(10) UNSIGNED,
                          teamId     INT(10) UNSIGNED, championNumber INT)
  RETURNS INT(10) UNSIGNED
  BEGIN
	INSERT INTO player VALUES(NULL,playerName,playerPosition,playerNumber,teamId,championNumber);
	RETURN LAST_INSERT_ID();
END;
