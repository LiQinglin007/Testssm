CREATE PROCEDURE detelePlayerByIdReturnPlayerSum(IN id INT(10) UNSIGNED, OUT playerSum INT(10) UNSIGNED)
  BEGIN
DELETE FROM player WHERE player.playerId=id;
SELECT COUNT(player.playerId) FROM player INTO playerSum;
END;
