CREATE FUNCTION f1()
  RETURNS VARCHAR(30)
  return DATE_FORMAT(NOW(),'%Y年%m月%d日 %H点:%i分:%s秒');
